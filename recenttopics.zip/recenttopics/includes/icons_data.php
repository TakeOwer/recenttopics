<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 * 
 * This file provides the icons data for the Recent Topics Extension.
 * It contains SVG definitions for all available icons and methods to access them.
 * The icons are based on Feather Icons (https://feathericons.com/) which are
 * lightweight, simple, and accessible SVG icons.
 */

namespace salvocortesiano\recenttopics\includes;

/**
 * Class containing icon data and utility methods for managing icons
 * Used to maintain a centralized collection of all available icons for the extension
 */
class icons_data
{
    /**
     * Get all available icons with their SVG data
     *
     * @return array Array of icon data with keys:
     *               - name: Language variable for the icon name
     *               - svg: SVG markup for the icon
     */
    public static function get_icons()
    {
        return array(
            'star' => array(
                'name' => 'RECENTTOPICS_ICON_STAR',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>'
            ),
            'zap' => array(
                'name' => 'RECENTTOPICS_ICON_ZAP',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zap"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>'
            ),
            'clock' => array(
                'name' => 'RECENTTOPICS_ICON_CLOCK',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>'
            ),
            'bell' => array(
                'name' => 'RECENTTOPICS_ICON_BELL',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>'
            ),
            'alert-circle' => array(
                'name' => 'RECENTTOPICS_ICON_ALERT_CIRCLE',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-alert-circle"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>'
            ),
            'message-circle' => array(
                'name' => 'RECENTTOPICS_ICON_MESSAGE_CIRCLE',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-message-circle"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>'
            ),
            'fire' => array(
                'name' => 'RECENTTOPICS_ICON_FIRE',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trending-up"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>'
            ),
            'award' => array(
                'name' => 'RECENTTOPICS_ICON_AWARD',
                'svg' => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-award"><circle cx="12" cy="8" r="7"></circle><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline></svg>'
            )
        );
    }

    /**
     * Get all icon options as array for select fields
     * This is used in the ACP to populate dropdown lists for icon selection
     *
     * @param \phpbb\language\language $language Language object
     * @return array Array of icon options with icon key as array key and localized name as value
     */
    public static function get_icon_options($language)
    {
        $icons = self::get_icons();
        $options = array();

        foreach ($icons as $key => $data)
        {
            $options[$key] = $language->lang($data['name']);
        }

        return $options;
    }

    /**
     * Get an icon SVG by its key
     * If the requested icon doesn't exist, falls back to the star icon
     *
     * @param string $icon_key The icon key to retrieve
     * @return string The icon SVG code ready for display
     */
    public static function get_icon_svg($icon_key)
    {
        $icons = self::get_icons();
        return isset($icons[$icon_key]) ? $icons[$icon_key]['svg'] : $icons['star']['svg'];
    }
}
