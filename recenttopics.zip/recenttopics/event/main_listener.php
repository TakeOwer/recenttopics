<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * Main event listener that handles the core functionality of detecting and marking recent topics.
 * This file is responsible for calculating which topics are considered recent based on their creation timestamp
 * and applying the appropriate icons and CSS classes to them.
 */

namespace salvocortesiano\recenttopics\event;

/**
 * @ignore
 */
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Event listener for Recent Topics functionality
 */
class main_listener implements EventSubscriberInterface
{
    /** @var \phpbb\config\config */
    protected $config;

    /** @var \phpbb\template\template */
    protected $template;

    /** @var \phpbb\user */
    protected $user;

    /** @var \phpbb\language\language */
    protected $language;

    /**
     * Constructor
     *
     * @param \phpbb\config\config        $config      Config object
     * @param \phpbb\template\template    $template    Template object
     * @param \phpbb\user                 $user        User object
     * @param \phpbb\language\language    $language    Language object
     */
    public function __construct(\phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user, \phpbb\language\language $language)
    {
        $this->config = $config;
        $this->template = $template;
        $this->user = $user;
        $this->language = $language;
    }

    /**
     * Assign functions defined in this class to event listeners in the core
     *
     * @return array
     */
    public static function getSubscribedEvents()
    {
        return array(
            'core.user_setup' => 'load_language_on_setup',
            'core.viewforum_modify_topicrow' => 'modify_topicrow',
        );
    }

    /**
     * Load common language files during user setup
     *
     * @param \phpbb\event\data $event Event object
     * @return void
     */
    public function load_language_on_setup($event)
    {
        $lang_set_ext = $event['lang_set_ext'];
        $lang_set_ext[] = array(
            'ext_name' => 'salvocortesiano/recenttopics',
            'lang_set' => 'common',
        );
        $event['lang_set_ext'] = $lang_set_ext;
    }

    /**
     * Modify the topic row for displaying the "new topic" icon
     *
     * @param \phpbb\event\data $event Event object
     * @return void
     */
    public function modify_topicrow($event)
    {
        // If the extension is disabled, do nothing
        if (empty($this->config['recenttopics_enabled']))
        {
            return;
        }
        
        // Get the current forum ID
        $topic_data = $event['topic_row'];
        $forum_id = isset($topic_data['FORUM_ID']) ? (int)$topic_data['FORUM_ID'] : 0;
        
        // Check if we should skip this forum based on settings
        if ($forum_id > 0 && !empty($this->config['recenttopics_forums']))
        {
            $selected_forums = explode(',', $this->config['recenttopics_forums']);
            
            // If forum selection is active and this forum is not in the list, skip it
            // Note: 0 is special value meaning "all forums"
            if (!in_array(0, $selected_forums) && !in_array($forum_id, $selected_forums))
            {
                return;
            }
        }

        // Get the current time
        $now = time();
        
        // Get the topic timestamp from the event
        $topic_data = $event['topic_row'];
        $topic_id = $topic_data['TOPIC_ID'];
        
        // Definiamo una funzione interna per analizzare le stringhe di data
        $parse_date_string = function($date_string) {
            // Registriamo i tentativi di matching in un array per debug
            $attempts = [];
            
            // 3. Formato: DD/MM/YYYY, HH:MM (spesso usato in italiano)
            if (preg_match('/(\d{2})\/(\d{2})\/(\d{4})[,\s]+(\d{2}):(\d{2})/', $date_string, $matches)) {
                $attempts[] = 'DD/MM/YYYY, HH:MM';
                return [
                    'year' => (int)$matches[3],
                    'month' => (int)$matches[2], 
                    'day' => (int)$matches[1],
                    'hour' => (int)$matches[4],
                    'minute' => (int)$matches[5]
                ];
            }
            
            // 4. Formato: DD/MM/YYYY HH:MM (senza virgola)
            if (preg_match('/(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})/', $date_string, $matches)) {
                $attempts[] = 'DD/MM/YYYY HH:MM';
                return [
                    'year' => (int)$matches[3],
                    'month' => (int)$matches[2], 
                    'day' => (int)$matches[1],
                    'hour' => (int)$matches[4],
                    'minute' => (int)$matches[5]
                ];
            }
            
            // 1. Formato: DD-MM-YYYY HH:MM
            if (preg_match('/(\d{2})-(\d{2})-(\d{4})\s+(\d{2}):(\d{2})/', $date_string, $matches)) {
                $attempts[] = 'DD-MM-YYYY HH:MM';
                return [
                    'year' => (int)$matches[3],
                    'month' => (int)$matches[2], 
                    'day' => (int)$matches[1],
                    'hour' => (int)$matches[4],
                    'minute' => (int)$matches[5]
                ];
            }
            
            // 2. Formato: YYYY-MM-DD HH:MM
            if (preg_match('/(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})/', $date_string, $matches)) {
                $attempts[] = 'YYYY-MM-DD HH:MM';
                return [
                    'year' => (int)$matches[1],
                    'month' => (int)$matches[2], 
                    'day' => (int)$matches[3],
                    'hour' => (int)$matches[4],
                    'minute' => (int)$matches[5]
                ];
            }
            
            // 5. Ottieni solo la data, senza ora 
            // Formato: DD/MM/YYYY
            if (preg_match('/(\d{2})\/(\d{2})\/(\d{4})/', $date_string, $matches)) {
                $attempts[] = 'DD/MM/YYYY';
                return [
                    'year' => (int)$matches[3],
                    'month' => (int)$matches[2], 
                    'day' => (int)$matches[1],
                    'hour' => 12, // Default a mezzogiorno
                    'minute' => 0
                ];
            }
            
            // 6. Formato semplice con testo: "08/03/2025, 21:37"
            if (preg_match('/(\d{1,2})\/(\d{1,2})\/(\d{4})/', $date_string, $matches)) {
                $attempts[] = 'D/M/YYYY';
                return [
                    'year' => (int)$matches[3],
                    'month' => (int)$matches[2], 
                    'day' => (int)$matches[1],
                    'hour' => 12, // Default a mezzogiorno
                    'minute' => 0  
                ];
            }
            
            return null;
        };

        // Prova diversi modi per ottenere il timestamp del topic
        $topic_time = 0;
        
        // Debug: Controlla cosa è disponibile nel topic_data
        $available_time_fields = [];
        foreach ($topic_data as $key => $value) {
            if (stripos($key, 'TIME') !== false || stripos($key, 'DATE') !== false || stripos($key, 'POST') !== false) {
                $available_time_fields[$key] = $value;
            }
        }
        
        // 1. Prima cerca "Ultimo messaggio" che è visibile nell'interfaccia
        if (isset($topic_data['LAST_POST_TIME'])) {
            // Se è già un timestamp
            if (is_numeric($topic_data['LAST_POST_TIME']) && (int)$topic_data['LAST_POST_TIME'] > 0) {
                $topic_time = (int)$topic_data['LAST_POST_TIME'];
            }
            // Se è una stringa di data, prova a convertirla
            else {
                $date_parts = $parse_date_string($topic_data['LAST_POST_TIME']);
                if ($date_parts) {
                    $topic_time = mktime(
                        $date_parts['hour'], 
                        $date_parts['minute'], 
                        0, 
                        $date_parts['month'], 
                        $date_parts['day'], 
                        $date_parts['year']
                    );
                }
            }
        }
        
        // 2. Prova con altri campi temporali se ancora non abbiamo un timestamp valido
        if ($topic_time <= 0) {
            // Cerca nell'array di date disponibili
            foreach ($available_time_fields as $field => $value) {
                // Se è già un timestamp
                if (is_numeric($value) && (int)$value > 0) {
                    $topic_time = (int)$value;
                    break;
                }
                // Se è una stringa di data
                else {
                    $date_parts = $parse_date_string($value);
                    if ($date_parts) {
                        $topic_time = mktime(
                            $date_parts['hour'], 
                            $date_parts['minute'], 
                            0, 
                            $date_parts['month'], 
                            $date_parts['day'], 
                            $date_parts['year']
                        );
                        break;
                    }
                }
            }
        }
        
        // 3. Se ancora non abbiamo un timestamp, prova nel rowset
        if ($topic_time <= 0 && isset($event['rowset']))
        {
            $topic_rowset = $event['rowset'];
            if (isset($topic_rowset[$topic_id]['topic_time']))
            {
                $topic_time = (int) $topic_rowset[$topic_id]['topic_time'];
            } 
            else if (isset($topic_rowset[$topic_id]['topic_posted']))
            {
                $topic_time = (int) $topic_rowset[$topic_id]['topic_posted'];
            }
            else if (isset($topic_rowset[$topic_id]['topic_last_post_time']))
            {
                $topic_time = (int) $topic_rowset[$topic_id]['topic_last_post_time'];
            }
        }
        
        // Se tutto fallisce, usa l'ora corrente meno un giorno così da mostrare comunque l'icona
        if ($topic_time <= 0)
        {
            $topic_time = $now - 86400; // 1 giorno fa
        }
        
        // Calculate the topic age in days
        $topic_age_days = ($now - $topic_time) / 86400; // 86400 seconds = 1 day
        
        // Verifica che la data non sia nel futuro e sia coerente
        $current_year = date('Y', $now);
        $topic_year = date('Y', $topic_time);
        $topic_time_valid = true;
        
        // Se l'anno è nel futuro o molto nel passato (più di 5 anni fa), 
        // probabilmente è un errore di interpretazione della data
        if ($topic_year > $current_year || $topic_year < ($current_year - 5)) {
            $topic_time_valid = false;
        }
        
        // Se il timestamp è nel futuro, non può essere valido
        if ($topic_time > $now) {
            $topic_time_valid = false;
        }
        
        // Get configuration values
        $recent_days = (int) $this->config['recenttopics_days'];
        $old_days = (int) $this->config['recenttopics_old_days'];
        
        // Check if we should show icons for this topic
        // Either it's recent (less than recent_days) and date is valid, OR we've enabled the show_all_topics option
        $show_all_topics = (bool) $this->config['recenttopics_show_all_topics'];
        $is_recent = (($topic_age_days < $recent_days && $topic_time_valid) || $show_all_topics);
        
        if ($is_recent)
        {
            // Use the icons data class statically (no need to instantiate)
            
            // Determine which tier the topic belongs to
            $tier1_days = (int) $this->config['recenttopics_days_tier1'];
            $tier2_days = (int) $this->config['recenttopics_days_tier2'];
            $tier3_days = (int) $this->config['recenttopics_days_tier3'];
            
            // Set appropriate title, tier and icon based on age
            $tier = 3; // Default to tier 3 (less recent)
            $title = $this->language->lang('RECENTTOPICS_LESS_RECENT');
            $icon_key = $this->config['recenttopics_icon_tier3'];
            
            if ($topic_age_days <= $tier1_days) {
                $tier = 1; // Very recent
                $title = $this->language->lang('RECENTTOPICS_VERY_RECENT');
                $icon_key = $this->config['recenttopics_icon_tier1'];
            } 
            else if ($topic_age_days <= $tier2_days) {
                $tier = 2; // Medium recent
                $title = $this->language->lang('RECENTTOPICS_MEDIUM_RECENT');
                $icon_key = $this->config['recenttopics_icon_tier2'];
            }
            
            // Get the SVG for this icon
            $icon_svg = \salvocortesiano\recenttopics\includes\icons_data::get_icon_svg($icon_key);
            
            // Assign template variables for this topic
            $topic_row = $event['topic_row'];
            $topic_row['S_RECENT_TOPIC'] = true;
            $topic_row['S_RECENT_TOPIC_TIER'] = $tier;
            $topic_row['S_RECENT_TOPIC_TITLE'] = $title;
            $topic_row['S_RECENT_TOPIC_ANIMATION'] = (bool) $this->config['recenttopics_animation'];
            $topic_row['S_RECENT_TOPIC_ICON'] = $icon_svg;
            
            // Update the event data
            $event['topic_row'] = $topic_row;
        }
        else
        {
            // Not a recent topic, make sure the variable is not set
            $topic_row = $event['topic_row'];
            $topic_row['S_RECENT_TOPIC'] = false;
            $event['topic_row'] = $topic_row;
        }
    }
}
