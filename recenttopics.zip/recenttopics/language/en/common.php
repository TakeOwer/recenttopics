<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

// Some characters you may want to copy&paste: ' » " " …
$lang = array_merge($lang, array(
    'RECENTTOPICS_FORUMS'         => 'Forums to display icons',
    'RECENTTOPICS_FORUMS_EXPLAIN' => 'Select the forums where you want the recent topic icons to appear. Hold CTRL to select multiple forums. Select "All Forums" to display in all forums.',
    'RECENTTOPICS_ALL_FORUMS'     => 'All Forums',
	
	'RECENTTOPICS_RECENT'        => 'Recent Topic',
    'RECENTTOPICS_VERY_RECENT'   => 'Very Recent Topic (posted within 1 day)',
    'RECENTTOPICS_MEDIUM_RECENT' => 'Medium Recent Topic (posted within 3 days)',
    'RECENTTOPICS_LESS_RECENT'   => 'Less Recent Topic (posted within 7 days)',
    
    // Icon names
    'RECENTTOPICS_ICON_STAR'          => 'Star',
    'RECENTTOPICS_ICON_ZAP'           => 'Lightning',
    'RECENTTOPICS_ICON_CLOCK'         => 'Clock',
    'RECENTTOPICS_ICON_BELL'          => 'Bell',
    'RECENTTOPICS_ICON_ALERT_CIRCLE'  => 'Alert Circle',
    'RECENTTOPICS_ICON_MESSAGE_CIRCLE' => 'Message Circle',
    'RECENTTOPICS_ICON_FIRE'          => 'Fire/Trending',
    'RECENTTOPICS_ICON_AWARD'         => 'Award/Medal',
));