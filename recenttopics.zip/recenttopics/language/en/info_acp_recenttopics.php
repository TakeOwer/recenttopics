<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

// Some characters you may want to copy&paste: ' » " " …
$lang = array_merge($lang, array(
    'ACP_RECENTTOPICS_TITLE'         => 'Recent Topics',
    'ACP_RECENTTOPICS_SETTINGS'      => 'Settings',
    'ACP_RECENTTOPICS_STATISTICS'    => 'Statistics',
    'ACP_RECENTTOPICS_SETTINGS_SAVED' => 'Recent Topics settings have been saved successfully!',
    
    'RECENTTOPICS_SETTINGS_TITLE'    => 'Recent Topics Settings',
    'RECENTTOPICS_SETTINGS_EXPLAIN'  => 'Here you can configure the settings for the Recent Topics extension.',
    
    'RECENTTOPICS_STATISTICS_TITLE'  => 'Topic Creation Statistics',
    'RECENTTOPICS_STATISTICS_EXPLAIN' => 'This page shows the distribution of topic creation dates across your forum.',
    
    // Export labels
    'RECENTTOPICS_STATS_EXPORT_CSV' => 'Export CSV',
    'RECENTTOPICS_STATS_EXPORT_PDF' => 'Export PDF',
    'RECENTTOPICS_STATS_DATE_RANGE' => 'Date Range',
    'RECENTTOPICS_STATS_DATE_START' => 'Start Date',
    'RECENTTOPICS_STATS_DATE_END'   => 'End Date',
    'RECENTTOPICS_STATS_APPLY_FILTER' => 'Apply Filter',
    'RECENTTOPICS_STATS_ALL_TIME'   => 'All Time',
    'RECENTTOPICS_STATS_SUMMARY'    => 'Summary',
    'RECENTTOPICS_STATS_CATEGORY'   => 'Category',
    'RECENTTOPICS_STATS_COUNT'      => 'Count',
    'RECENTTOPICS_STATS_PERCENTAGE' => 'Percentage',
    'RECENTTOPICS_STATS_FORUM'      => 'Forum',
    'RECENTTOPICS_STATS_TOTAL_TOPICS' => 'Total topics',
    'RECENTTOPICS_STATS_FORUM_DISTRIBUTION' => 'Topic Distribution by Forum',
    
    'RECENTTOPICS_ENABLED'           => 'Enable Recent Topics',
    'RECENTTOPICS_ENABLED_EXPLAIN'   => 'Enable or disable the Recent Topics marker.',
    
    'RECENTTOPICS_FORUMS'            => 'Forums to display icons',
    'RECENTTOPICS_FORUMS_EXPLAIN'    => 'Select the forums where you want the recent topic icons to appear. Hold CTRL to select multiple forums. Select "All Forums" to display in all forums.',
    'RECENTTOPICS_ALL_FORUMS'        => 'All Forums',
    
    'RECENTTOPICS_DAYS'              => 'Maximum days to consider a topic recent',
    'RECENTTOPICS_DAYS_EXPLAIN'      => 'Number of days after creation that a topic is considered as recent and will be marked with an icon.',
    'RECENTTOPICS_DAYS_INVALID'      => 'The number of days must be between 1 and 365.',
    
    'RECENTTOPICS_OLD_DAYS'          => 'Days after which to consider a topic old',
    'RECENTTOPICS_OLD_DAYS_EXPLAIN'  => 'Number of days after which a topic is considered old and will no longer be shown with icons.',
    'RECENTTOPICS_OLD_DAYS_INVALID'  => 'The number of days must be greater than the maximum days to consider a topic recent and no more than 730 (2 years).',
    
    'RECENTTOPICS_ANIMATION'         => 'Enable icon animation',
    'RECENTTOPICS_ANIMATION_EXPLAIN' => 'Enable or disable the pulsing animation effect on the recent topics icon. Disabling may improve accessibility for some users.',
    
    'RECENTTOPICS_SHOW_ALL_TOPICS'    => 'Show icons for all topics',
    'RECENTTOPICS_SHOW_ALL_TOPICS_EXPLAIN' => 'Display icons for all topics regardless of their age. When enabled, even old topics will be marked with an icon.',
    
    'RECENTTOPICS_TIERED_ICONS'      => 'Age-based icon tiers',
    'RECENTTOPICS_TIERED_ICONS_EXPLAIN' => 'Configure different icon styles based on how recent a topic is.',
    
    'RECENTTOPICS_DAYS_TIER1'        => 'Very recent topics threshold (days)',
    'RECENTTOPICS_DAYS_TIER1_EXPLAIN' => 'Topics newer than this threshold will be marked with the "very recent" icon.',
    
    'RECENTTOPICS_DAYS_TIER2'        => 'Medium recent topics threshold (days)',
    'RECENTTOPICS_DAYS_TIER2_EXPLAIN' => 'Topics newer than this threshold will be marked with the "medium recent" icon.',
    
    'RECENTTOPICS_DAYS_TIER3'        => 'Less recent topics threshold (days)',
    'RECENTTOPICS_DAYS_TIER3_EXPLAIN' => 'Topics newer than this threshold will be marked with the "less recent" icon.',
    
    'RECENTTOPICS_DAYS_TIER_INVALID' => 'The tier values must be in ascending order (tier1 < tier2 < tier3) and less than or equal to the maximum days setting.',
    
    'RECENTTOPICS_ICON_SETTINGS'     => 'Icon Settings',
    'RECENTTOPICS_ICON_SETTINGS_EXPLAIN' => 'Choose which icons to use for each recency tier.',
    
    'RECENTTOPICS_ICON_TIER1'        => 'Very recent topics icon',
    'RECENTTOPICS_ICON_TIER1_EXPLAIN' => 'Select which icon to use for very recent topics (tier 1).',
    
    'RECENTTOPICS_ICON_TIER2'        => 'Medium recent topics icon',
    'RECENTTOPICS_ICON_TIER2_EXPLAIN' => 'Select which icon to use for medium recent topics (tier 2).',
    
    'RECENTTOPICS_ICON_TIER3'        => 'Less recent topics icon',
    'RECENTTOPICS_ICON_TIER3_EXPLAIN' => 'Select which icon to use for less recent topics (tier 3).',
    
    // Statistics page
    'RECENTTOPICS_STATS_TODAY'       => 'Today',
    'RECENTTOPICS_STATS_YESTERDAY'   => 'Yesterday',
    'RECENTTOPICS_STATS_LAST_WEEK'   => 'Last 7 days',
    'RECENTTOPICS_STATS_LAST_MONTH'  => 'Last 30 days',
    'RECENTTOPICS_STATS_LAST_YEAR'   => 'Last year',
    'RECENTTOPICS_STATS_OLDER'       => 'Older',
    
    'RECENTTOPICS_STATS_TOPICS_TOTAL' => 'Total topics',
    'RECENTTOPICS_STATS_TOPICS_RECENT' => 'Recent topics (within %s days)',
    'RECENTTOPICS_STATS_TOPICS_OLD' => 'Topics between %s and %s days old',
    'RECENTTOPICS_STATS_TOPICS_VERY_OLD' => 'Very old topics (older than %s days)',
    'RECENTTOPICS_STATS_AVG_TOPICS' => 'Average topics per day (last %s days)',
    'RECENTTOPICS_STATS_TOP_FORUMS' => 'Top forums by topic count',
    'RECENTTOPICS_STATS_DISTRIBUTION' => 'Topic age distribution',
    'RECENTTOPICS_STATS_NO_TOPICS'    => 'No topics found in this timeframe',
    'RECENTTOPICS_STATS_TIMEFRAME'    => 'Timeframe',
    'RECENTTOPICS_STATS_COUNT'        => 'Number of topics',
    'RECENTTOPICS_STATS_PERCENTAGE'   => 'Percentage',
    
    // Charts labels
    'RECENTTOPICS_STATS_BAR_CHART'    => 'Topic Age - Bar Chart',
    'RECENTTOPICS_STATS_PIE_CHART'    => 'Topic Age - Distribution Percentage',
    'RECENTTOPICS_STATS_CHART_TITLE'  => 'Topic Age Distribution',
    'RECENTTOPICS_STATS_TOPICS_BY_AGE' => 'Topics by Age Range',
    
    // Export options
    'RECENTTOPICS_STATS_EXPORT_CSV'   => 'Export to CSV',
    'RECENTTOPICS_STATS_EXPORT_PDF'   => 'Export to PDF',
    'RECENTTOPICS_STATS_EXPORT_TITLE' => 'Export Statistics',
    'RECENTTOPICS_STATS_DATE_RANGE'   => 'Date Range',
    'RECENTTOPICS_STATS_DATE_START'   => 'Start Date',
    'RECENTTOPICS_STATS_DATE_END'     => 'End Date',
    'RECENTTOPICS_STATS_APPLY_FILTER' => 'Apply Filter',
));
