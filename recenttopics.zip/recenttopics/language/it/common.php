<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

// Some characters you may want to copy&paste: ' » " " …
$lang = array_merge($lang, array(
    'RECENTTOPICS_FORUMS'         => 'Forum in cui mostrare le icone',
    'RECENTTOPICS_FORUMS_EXPLAIN' => 'Seleziona i forum dove vuoi che appaiano le icone degli argomenti recenti. Tieni premuto CTRL per selezionare più forum. Seleziona "Tutti i Forum" per mostrarle in tutti i forum.',
    'RECENTTOPICS_ALL_FORUMS'     => 'Tutti i Forum',
	
	'RECENTTOPICS_RECENT'        => 'Argomento Recente',
    'RECENTTOPICS_VERY_RECENT'   => 'Argomento Molto Recente (pubblicato entro 1 giorno)',
    'RECENTTOPICS_MEDIUM_RECENT' => 'Argomento Mediamente Recente (pubblicato entro 3 giorni)',
    'RECENTTOPICS_LESS_RECENT'   => 'Argomento Poco Recente (pubblicato entro 7 giorni)',
    
    // Icon names
    'RECENTTOPICS_ICON_STAR'          => 'Stella',
    'RECENTTOPICS_ICON_ZAP'           => 'Fulmine',
    'RECENTTOPICS_ICON_CLOCK'         => 'Orologio',
    'RECENTTOPICS_ICON_BELL'          => 'Campana',
    'RECENTTOPICS_ICON_ALERT_CIRCLE'  => 'Cerchio di Avviso',
    'RECENTTOPICS_ICON_MESSAGE_CIRCLE' => 'Cerchio Messaggio',
    'RECENTTOPICS_ICON_FIRE'          => 'Fuoco/Tendenza',
    'RECENTTOPICS_ICON_AWARD'         => 'Premio/Medaglia',
));