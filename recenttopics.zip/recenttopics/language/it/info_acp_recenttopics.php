<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

if (!defined('IN_PHPBB'))
{
    exit;
}

if (empty($lang) || !is_array($lang))
{
    $lang = array();
}

// Some characters you may want to copy&paste: ' » " " …
$lang = array_merge($lang, array(
    'ACP_RECENTTOPICS_TITLE'         => 'Argomenti Recenti',
    'ACP_RECENTTOPICS_SETTINGS'      => 'Impostazioni',
    'ACP_RECENTTOPICS_STATISTICS'    => 'Statistiche',
    'ACP_RECENTTOPICS_SETTINGS_SAVED' => 'Le impostazioni di Argomenti Recenti sono state salvate con successo!',
    
    'RECENTTOPICS_SETTINGS_TITLE'    => 'Impostazioni Argomenti Recenti',
    'RECENTTOPICS_SETTINGS_EXPLAIN'  => 'Qui puoi configurare le impostazioni per l\'estensione Argomenti Recenti.',
    
    'RECENTTOPICS_STATISTICS_TITLE'  => 'Statistiche Creazione Argomenti',
    'RECENTTOPICS_STATISTICS_EXPLAIN' => 'Questa pagina mostra la distribuzione delle date di creazione degli argomenti nel tuo forum.',
    
    // Export labels
    'RECENTTOPICS_STATS_EXPORT_CSV' => 'Esporta CSV',
    'RECENTTOPICS_STATS_EXPORT_PDF' => 'Esporta PDF',
    'RECENTTOPICS_STATS_DATE_RANGE' => 'Intervallo di date',
    'RECENTTOPICS_STATS_DATE_START' => 'Data di inizio',
    'RECENTTOPICS_STATS_DATE_END'   => 'Data di fine',
    'RECENTTOPICS_STATS_APPLY_FILTER' => 'Applica filtro',
    'RECENTTOPICS_STATS_ALL_TIME'   => 'Tutto il periodo',
    'RECENTTOPICS_STATS_SUMMARY'    => 'Riepilogo',
    'RECENTTOPICS_STATS_CATEGORY'   => 'Categoria',
    'RECENTTOPICS_STATS_COUNT'      => 'Conteggio',
    'RECENTTOPICS_STATS_PERCENTAGE' => 'Percentuale',
    'RECENTTOPICS_STATS_FORUM'      => 'Forum',
    'RECENTTOPICS_STATS_TOTAL_TOPICS' => 'Totale argomenti',
    'RECENTTOPICS_STATS_FORUM_DISTRIBUTION' => 'Distribuzione degli argomenti per forum',
    
    'RECENTTOPICS_ENABLED'           => 'Abilita Argomenti Recenti',
    'RECENTTOPICS_ENABLED_EXPLAIN'   => 'Abilita o disabilita il marcatore per Argomenti Recenti.',
    
    'RECENTTOPICS_DAYS'              => 'Giorni massimi per considerare un argomento recente',
    'RECENTTOPICS_DAYS_EXPLAIN'      => 'Numero di giorni dopo la creazione in cui un argomento è considerato recente e verrà contrassegnato con un\'icona.',
    'RECENTTOPICS_DAYS_INVALID'      => 'Il numero di giorni deve essere compreso tra 1 e 365.',
    
    'RECENTTOPICS_OLD_DAYS'          => 'Giorni dopo i quali considerare un argomento vecchio',
    'RECENTTOPICS_OLD_DAYS_EXPLAIN'  => 'Numero di giorni dopo i quali un argomento è considerato vecchio e non verrà più mostrato con icone.',
    'RECENTTOPICS_OLD_DAYS_INVALID'  => 'Il numero di giorni deve essere maggiore dei giorni massimi per considerare un argomento recente e non superiore a 730 (2 anni).',
    
    'RECENTTOPICS_ANIMATION'         => 'Abilita animazione icona',
    'RECENTTOPICS_ANIMATION_EXPLAIN' => 'Abilita o disabilita l\'effetto di animazione pulsante sull\'icona degli argomenti recenti. La disabilitazione può migliorare l\'accessibilità per alcuni utenti.',
    
    'RECENTTOPICS_SHOW_ALL_TOPICS'    => 'Mostra icone per tutti gli argomenti',
    'RECENTTOPICS_SHOW_ALL_TOPICS_EXPLAIN' => 'Visualizza le icone per tutti gli argomenti indipendentemente dalla loro età. Quando abilitato, anche gli argomenti vecchi saranno contrassegnati con un\'icona.',
    
    'RECENTTOPICS_TIERED_ICONS'      => 'Icone basate sull\'età',
    'RECENTTOPICS_TIERED_ICONS_EXPLAIN' => 'Configura diversi stili di icone in base alla recenza di un argomento.',
    
    'RECENTTOPICS_DAYS_TIER1'        => 'Soglia argomenti molto recenti (giorni)',
    'RECENTTOPICS_DAYS_TIER1_EXPLAIN' => 'Gli argomenti più recenti di questa soglia saranno contrassegnati con l\'icona "molto recente".',
    
    'RECENTTOPICS_DAYS_TIER2'        => 'Soglia argomenti mediamente recenti (giorni)',
    'RECENTTOPICS_DAYS_TIER2_EXPLAIN' => 'Gli argomenti più recenti di questa soglia saranno contrassegnati con l\'icona "mediamente recente".',
    
    'RECENTTOPICS_DAYS_TIER3'        => 'Soglia argomenti poco recenti (giorni)',
    'RECENTTOPICS_DAYS_TIER3_EXPLAIN' => 'Gli argomenti più recenti di questa soglia saranno contrassegnati con l\'icona "poco recente".',
    
    'RECENTTOPICS_DAYS_TIER_INVALID' => 'I valori delle soglie devono essere in ordine crescente (tier1 < tier2 < tier3) e minori o uguali all\'impostazione dei giorni massimi.',
    
    'RECENTTOPICS_ICON_SETTINGS'     => 'Impostazioni Icona',
    'RECENTTOPICS_ICON_SETTINGS_EXPLAIN' => 'Scegli quali icone utilizzare per ciascuna fascia di recenza.',
    
    'RECENTTOPICS_ICON_TIER1'        => 'Icona argomenti molto recenti',
    'RECENTTOPICS_ICON_TIER1_EXPLAIN' => 'Seleziona quale icona utilizzare per gli argomenti molto recenti (fascia 1).',
    
    'RECENTTOPICS_ICON_TIER2'        => 'Icona argomenti mediamente recenti',
    'RECENTTOPICS_ICON_TIER2_EXPLAIN' => 'Seleziona quale icona utilizzare per gli argomenti mediamente recenti (fascia 2).',
    
    'RECENTTOPICS_ICON_TIER3'        => 'Icona argomenti poco recenti',
    'RECENTTOPICS_ICON_TIER3_EXPLAIN' => 'Seleziona quale icona utilizzare per gli argomenti poco recenti (fascia 3).',
    
    // Statistics page
    'RECENTTOPICS_STATS_TODAY'       => 'Oggi',
    'RECENTTOPICS_STATS_YESTERDAY'   => 'Ieri',
    'RECENTTOPICS_STATS_LAST_WEEK'   => 'Ultimi 7 giorni',
    'RECENTTOPICS_STATS_LAST_MONTH'  => 'Ultimi 30 giorni',
    'RECENTTOPICS_STATS_LAST_YEAR'   => 'Ultimo anno',
    'RECENTTOPICS_STATS_OLDER'       => 'Più vecchi',
    
    'RECENTTOPICS_STATS_TOPICS_TOTAL' => 'Argomenti totali',
    'RECENTTOPICS_STATS_TOPICS_RECENT' => 'Argomenti recenti (entro %s giorni)',
    'RECENTTOPICS_STATS_TOPICS_OLD' => 'Argomenti tra %s e %s giorni',
    'RECENTTOPICS_STATS_TOPICS_VERY_OLD' => 'Argomenti molto vecchi (più di %s giorni)',
    'RECENTTOPICS_STATS_AVG_TOPICS' => 'Media argomenti al giorno (ultimi %s giorni)',
    'RECENTTOPICS_STATS_TOP_FORUMS' => 'Forum principali per numero di argomenti',
    'RECENTTOPICS_STATS_DISTRIBUTION' => 'Distribuzione età argomenti',
    'RECENTTOPICS_STATS_NO_TOPICS'    => 'Nessun argomento trovato in questo periodo',
    'RECENTTOPICS_STATS_TIMEFRAME'    => 'Periodo',
    'RECENTTOPICS_STATS_COUNT'        => 'Numero di argomenti',
    'RECENTTOPICS_STATS_PERCENTAGE'   => 'Percentuale',
    
    // Etichette grafici
    'RECENTTOPICS_STATS_BAR_CHART'    => 'Età Argomenti - Grafico a Barre',
    'RECENTTOPICS_STATS_PIE_CHART'    => 'Età Argomenti - Distribuzione Percentuale',
    'RECENTTOPICS_STATS_CHART_TITLE'  => 'Distribuzione Età Argomenti',
    'RECENTTOPICS_STATS_TOPICS_BY_AGE' => 'Argomenti per Fascia di Età',
    
    // Opzioni di esportazione
    'RECENTTOPICS_STATS_EXPORT_CSV'   => 'Esporta in CSV',
    'RECENTTOPICS_STATS_EXPORT_PDF'   => 'Esporta in PDF',
    'RECENTTOPICS_STATS_EXPORT_TITLE' => 'Esporta Statistiche',
    'RECENTTOPICS_STATS_DATE_RANGE'   => 'Intervallo di Date',
    'RECENTTOPICS_STATS_DATE_START'   => 'Data Inizio',
    'RECENTTOPICS_STATS_DATE_END'     => 'Data Fine',
    'RECENTTOPICS_STATS_APPLY_FILTER' => 'Applica Filtro',
));
