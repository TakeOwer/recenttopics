/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */
(function($) {
    'use strict';
    
    /**
     * Adjusts the icon size based on parent font size for better visual consistency
     * across different themes and screen sizes.
     */
    function adjustIconSize() {
        $('.recenttopics-icon').each(function() {
            var $icon = $(this);
            var fontSize = parseInt($icon.parent().css('font-size'), 10);
            
            // Handle case where fontSize might not be available
            if (isNaN(fontSize)) {
                fontSize = 14; // Default size if we can't determine parent size
            }
            
            // Enhanced size calculation for better scaling
            var newSize;
            if (fontSize > 14) {
                newSize = Math.min(Math.round(fontSize * 1.1), 24);
            } else if (fontSize < 12) {
                newSize = Math.max(Math.round(fontSize * 1.1), 12);
            } else {
                newSize = fontSize; // Keep proportional for medium sizes
            }
            
            // Apply calculated size with improved positioning
            $icon.find('svg').css({
                'width': newSize + 'px',
                'height': newSize + 'px',
                'vertical-align': 'middle' // Better alignment
            });
            
            // Add tooltip functionality when browser doesn't support title
            if (!('title' in document.createElement('svg'))) {
                var title = $icon.attr('title');
                if (title && title.length > 0) {
                    $icon.attr('aria-label', title);
                }
            }
        });
    }
    
    // Run when DOM is ready with improved error handling
    $(function() {
        try {
            adjustIconSize();
            
            // Improved throttled resize handler with better performance
            var resizeTimeout;
            $(window).on('resize', function() {
                if (!resizeTimeout) {
                    resizeTimeout = setTimeout(function() {
                        try {
                            adjustIconSize();
                        } catch(e) {
                            console.error('RecentTopics: Error adjusting icons:', e);
                        }
                        resizeTimeout = null;
                    }, 250); // Slightly more responsive
                }
            });
            
            // Also adjust when images load to account for layout shifts
            $(window).on('load', adjustIconSize);
        } catch(e) {
            console.error('RecentTopics: Initialization error:', e);
        }
    });
    
})(jQuery);
