<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

namespace salvocortesiano\recenttopics\controller;

/**
 * Admin Control Panel controller
 */
class acp_controller
{
    /** @var \phpbb\config\config */
    protected $config;
    
    /** @var \phpbb\template\template */
    protected $template;
    
    /** @var \phpbb\language\language */
    protected $language;
    
    /** @var \phpbb\request\request */
    protected $request;
    
    /** @var \phpbb\user */
    protected $user;
    
    /** @var \phpbb\db\driver\driver_interface */
    protected $db;
    
    /** @var string Custom form action */
    protected $u_action;

    /**
     * Constructor
     *
     * @param \phpbb\config\config      $config   Config object
     * @param \phpbb\template\template  $template Template object
     * @param \phpbb\language\language  $language Language object
     * @param \phpbb\request\request    $request  Request object
     * @param \phpbb\user               $user     User object
     * @param \phpbb\db\driver\driver_interface $db Database object
     */
    public function __construct(\phpbb\config\config $config, \phpbb\template\template $template, \phpbb\language\language $language, \phpbb\request\request $request, \phpbb\user $user, \phpbb\db\driver\driver_interface $db)
    {
        $this->config   = $config;
        $this->template = $template;
        $this->language = $language;
        $this->request  = $request;
        $this->user     = $user;
        $this->db       = $db;
    }

    /**
     * Display the settings page
     *
     * @return void
     */
    public function display_settings()
    {
        // Add language files
        $this->language->add_lang('info_acp_recenttopics', 'salvocortesiano/recenttopics');
        $this->language->add_lang('common', 'salvocortesiano/recenttopics');
        
        // Get icons data
        $icons_data = new \salvocortesiano\recenttopics\includes\icons_data();
        $icon_options = $icons_data::get_icon_options($this->language);
        
        // Create a form key for preventing CSRF attacks
        add_form_key('salvocortesiano_recenttopics_settings');
        
        // Create an array to collect errors triggered during the form validation
        $errors = array();
        
        // Is the form submitted?
        if ($this->request->is_set_post('submit'))
        {
            // Test if the submitted form is valid
            if (!check_form_key('salvocortesiano_recenttopics_settings'))
            {
                $errors[] = $this->language->lang('FORM_INVALID');
            }
            
            // Validate the days value is within reasonable limits
            $recenttopics_days = $this->request->variable('recenttopics_days', 7);
            if ($recenttopics_days < 1 || $recenttopics_days > 365)
            {
                $errors[] = $this->language->lang('RECENTTOPICS_DAYS_INVALID');
            }
            
            // Validate the old days value is within reasonable limits
            $recenttopics_old_days = $this->request->variable('recenttopics_old_days', 90);
            if ($recenttopics_old_days < $recenttopics_days || $recenttopics_old_days > 730) // Max 2 years
            {
                $errors[] = $this->language->lang('RECENTTOPICS_OLD_DAYS_INVALID');
            }
            
            // Get tier values
            $tier1 = $this->request->variable('recenttopics_days_tier1', 1);
            $tier2 = $this->request->variable('recenttopics_days_tier2', 3);
            $tier3 = $this->request->variable('recenttopics_days_tier3', 7);
            
            // Validate tier values are in correct order and within the maximum days
            if ($tier1 < 1 || $tier2 <= $tier1 || $tier3 <= $tier2 || $tier3 > $recenttopics_days)
            {
                $errors[] = $this->language->lang('RECENTTOPICS_DAYS_TIER_INVALID');
            }
            
            // Get icon selections
            $icon_tier1 = $this->request->variable('recenttopics_icon_tier1', 'star');
            $icon_tier2 = $this->request->variable('recenttopics_icon_tier2', 'zap');
            $icon_tier3 = $this->request->variable('recenttopics_icon_tier3', 'clock');
            
            // Validate icon selections
            if (!isset($icon_options[$icon_tier1]) || !isset($icon_options[$icon_tier2]) || !isset($icon_options[$icon_tier3]))
            {
                $errors[] = $this->language->lang('FORM_INVALID');
            }
            
            // If no errors, process the form data
            if (empty($errors))
            {
                // Set the options the user configured
                $this->config->set('recenttopics_enabled', $this->request->variable('recenttopics_enabled', 0));
                $this->config->set('recenttopics_days', $recenttopics_days);
                $this->config->set('recenttopics_old_days', $recenttopics_old_days);
                $this->config->set('recenttopics_animation', $this->request->variable('recenttopics_animation', 0));
                $this->config->set('recenttopics_show_all_topics', $this->request->variable('recenttopics_show_all_topics', 0));
                $this->config->set('recenttopics_days_tier1', $tier1);
                $this->config->set('recenttopics_days_tier2', $tier2);
                $this->config->set('recenttopics_days_tier3', $tier3);
                $this->config->set('recenttopics_icon_tier1', $icon_tier1);
                $this->config->set('recenttopics_icon_tier2', $icon_tier2);
                $this->config->set('recenttopics_icon_tier3', $icon_tier3);
                
                // Salva l'elenco dei forum selezionati
                $selected_forums = $this->request->variable('recenttopics_forums', array(0));
                
                // Assicurati che se nessun forum è selezionato, non venga impostato "Tutti i forum" come default
                if (count($selected_forums) == 1 && $selected_forums[0] == 0) {
                    // L'utente ha selezionato solo "Tutti i forum"
                    $selected_forums_serialized = '0';
                } elseif (count($selected_forums) > 0) {
                    // L'utente ha selezionato forum specifici (escludiamo 0 se presente insieme ad altri forum)
                    $specific_forums = array_filter($selected_forums, function($forum_id) {
                        return $forum_id > 0;
                    });
                    $selected_forums_serialized = implode(',', $specific_forums);
                } else {
                    // Nessun forum selezionato, lasciare vuoto
                    $selected_forums_serialized = '';
                }
                
                $this->config->set('recenttopics_forums', $selected_forums_serialized);
                
                // Add option settings change success message
                trigger_error($this->language->lang('ACP_RECENTTOPICS_SETTINGS_SAVED') . adm_back_link($this->u_action));
            }
        }
        
        // Prepare icon preview data
        $icon_previews = array();
        foreach ($icon_options as $key => $name)
        {
            $icon_previews[$key] = $icons_data::get_icon_svg($key);
        }
        
        // Set output variables for display in the template
        $this->template->assign_vars(array(
            'S_ERROR'               => (sizeof($errors)) ? true : false,
            'ERROR_MSG'             => (sizeof($errors)) ? implode('<br />', $errors) : '',
            
            'U_ACTION'              => $this->u_action,
            
            'RECENTTOPICS_ENABLED'        => $this->config['recenttopics_enabled'],
            'RECENTTOPICS_DAYS'           => $this->config['recenttopics_days'],
            'RECENTTOPICS_OLD_DAYS'       => $this->config['recenttopics_old_days'],
            'RECENTTOPICS_ANIMATION'      => $this->config['recenttopics_animation'],
            'RECENTTOPICS_SHOW_ALL_TOPICS' => $this->config['recenttopics_show_all_topics'],
            'RECENTTOPICS_DAYS_TIER1' => $this->config['recenttopics_days_tier1'],
            'RECENTTOPICS_DAYS_TIER2' => $this->config['recenttopics_days_tier2'],
            'RECENTTOPICS_DAYS_TIER3' => $this->config['recenttopics_days_tier3'],
            'RECENTTOPICS_ICON_TIER1' => $this->config['recenttopics_icon_tier1'],
            'RECENTTOPICS_ICON_TIER2' => $this->config['recenttopics_icon_tier2'],
            'RECENTTOPICS_ICON_TIER3' => $this->config['recenttopics_icon_tier3'],
            
            'S_ICON_OPTIONS'          => $icon_options,
            'ICON_PREVIEWS'           => $icon_previews,
            
            // Forum selection
            'S_FORUM_OPTIONS'         => $this->get_forum_options(),
        ));
    }

    /**
     * Display the statistics page
     *
     * @return void
     */
    public function display_statistics()
    {
        // Add language file
        $this->language->add_lang('info_acp_recenttopics', 'salvocortesiano/recenttopics');
        
        // Process action (for exports)
        $action = $this->request->variable('action', '');
        
        // Process date filter form if submitted
        $start_date = $this->request->variable('start_date', '');
        $end_date = $this->request->variable('end_date', '');
        $filter_active = false;
        
        // Check if we need to export data
        if ($action === 'csv' || $action === 'pdf')
        {
            $this->export_statistics($action, $start_date, $end_date);
            return;
        }
        
        // Time boundaries
        $start_time = 0;
        $end_time = time(); // Current time
        
        // Convert date filters to timestamps if provided
        if (!empty($start_date))
        {
            $date_parts = explode('-', $start_date);
            if (count($date_parts) === 3)
            {
                $start_time = mktime(0, 0, 0, (int) $date_parts[1], (int) $date_parts[2], (int) $date_parts[0]);
                $filter_active = true;
            }
        }
        
        if (!empty($end_date))
        {
            $date_parts = explode('-', $end_date);
            if (count($date_parts) === 3)
            {
                $end_time = mktime(23, 59, 59, (int) $date_parts[1], (int) $date_parts[2], (int) $date_parts[0]);
                $filter_active = true;
            }
        }
        
        // Get the current time
        $now = time();
        
        // Apply date filter to SQL queries if active
        $date_filter_sql = '';
        if ($filter_active)
        {
            $date_filter_sql = ' AND topic_time >= ' . $start_time . ' AND topic_time <= ' . $end_time;
        }
        
        // Get total number of topics
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $total_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get recent topics
        $recent_days = (int) $this->config['recenttopics_days'];
        $recent_time = $now - ($recent_days * 24 * 60 * 60);
        
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time >= ' . $recent_time . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $recent_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Apply date filter to distribution queries if active
        $distribution_date_filter = '';
        if ($filter_active)
        {
            // If we have date filters, we need to adjust our distribution calculations
            $distribution_date_filter = ' AND topic_time >= ' . $start_time . ' AND topic_time <= ' . $end_time;
        }
        
        // Calculate distribution for various time periods
        $time_periods = array(
            array(
                'name' => 'RECENTTOPICS_STATS_TODAY',
                'start' => $now - (24 * 60 * 60),
                'count' => 0,
                'percentage' => 0,
            ),
            array(
                'name' => 'RECENTTOPICS_STATS_YESTERDAY',
                'start' => $now - (2 * 24 * 60 * 60),
                'end' => $now - (24 * 60 * 60),
                'count' => 0,
                'percentage' => 0,
            ),
            array(
                'name' => 'RECENTTOPICS_STATS_LAST_WEEK',
                'start' => $now - (7 * 24 * 60 * 60),
                'end' => $now - (2 * 24 * 60 * 60),
                'count' => 0,
                'percentage' => 0,
            ),
            array(
                'name' => 'RECENTTOPICS_STATS_LAST_MONTH',
                'start' => $now - (30 * 24 * 60 * 60),
                'end' => $now - (7 * 24 * 60 * 60),
                'count' => 0,
                'percentage' => 0,
            ),
            array(
                'name' => 'RECENTTOPICS_STATS_LAST_YEAR',
                'start' => $now - (365 * 24 * 60 * 60),
                'end' => $now - (30 * 24 * 60 * 60),
                'count' => 0,
                'percentage' => 0,
            ),
            array(
                'name' => 'RECENTTOPICS_STATS_OLDER',
                'end' => $now - (365 * 24 * 60 * 60),
                'count' => 0,
                'percentage' => 0,
            ),
        );
        
        // Query for each time period
        foreach ($time_periods as &$period)
        {
            $sql_where = '';
            
            if (isset($period['start']))
            {
                $sql_where .= 'topic_time >= ' . (int) $period['start'];
            }
            
            if (isset($period['end']))
            {
                if ($sql_where)
                {
                    $sql_where .= ' AND ';
                }
                $sql_where .= 'topic_time < ' . (int) $period['end'];
            }
            
            // Costruiamo la query correttamente in base alla presenza di condizioni WHERE
            $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE;
            
            // Se abbiamo condizioni per il periodo, le aggiungiamo
            if (!empty($sql_where))
            {
                $sql .= ' WHERE ' . $sql_where;
                
                // Aggiungiamo le altre condizioni solo se abbiamo già un WHERE
                if ($distribution_date_filter)
                {
                    $sql .= $distribution_date_filter;
                }
                
                $sql .= ' AND topic_type <> ' . POST_GLOBAL;
            }
            else
            {
                // Se non abbiamo condizioni per il periodo, iniziamo con le altre
                $sql .= ' WHERE topic_type <> ' . POST_GLOBAL;
                
                if ($distribution_date_filter)
                {
                    $sql .= $distribution_date_filter;
                }
            }
            
            $result = $this->db->sql_query($sql);
            $period['count'] = (int) $this->db->sql_fetchfield('count');
            $this->db->sql_freeresult($result);
            
            // Verifica e debug
            if ($period['name'] === 'RECENTTOPICS_STATS_OLDER')
            {
                // Per il debug, salviamo l'SQL utilizzato
                $this->config->set('recenttopics_debug_sql', $sql);
                $this->config->set('recenttopics_debug_count', $period['count']);
            }
            
            // Calculate percentage
            $period['percentage'] = ($total_topics > 0) ? ($period['count'] / $total_topics) * 100 : 0;
        }
        
        // Get old topics (between recent_days and old_days)
        $old_days = (int) $this->config['recenttopics_old_days'];
        $old_time = $now - ($old_days * 24 * 60 * 60);
        
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time >= ' . $old_time . '
                AND topic_time < ' . $recent_time . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $old_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get very old topics (older than old_days)
        $very_old_time = $old_time;
        
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time < ' . $very_old_time . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $very_old_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get distribution of topics by forum
        $sql = 'SELECT f.forum_name, COUNT(t.topic_id) as count FROM ' . TOPICS_TABLE . ' t
                JOIN ' . FORUMS_TABLE . ' f ON t.forum_id = f.forum_id
                WHERE t.topic_type <> ' . POST_GLOBAL;
                
        if ($filter_active) {
            $sql .= ' AND t.topic_time >= ' . $start_time . ' AND t.topic_time <= ' . $end_time;
        }
        
        $sql .= ' GROUP BY f.forum_id
                ORDER BY count DESC
                LIMIT 5';
        $result = $this->db->sql_query($sql);
        
        $forum_distribution = array();
        while ($row = $this->db->sql_fetchrow($result))
        {
            $forum_distribution[] = array(
                'name' => $row['forum_name'],
                'count' => $row['count'],
                'percentage' => ($total_topics > 0) ? ($row['count'] / $total_topics) * 100 : 0,
            );
        }
        $this->db->sql_freeresult($result);
        
        // Calculate average topics per day for recent period
        $days_for_average = min(30, $recent_days); // Use at most last 30 days
        $start_time_avg = $now - ($days_for_average * 24 * 60 * 60);
        
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time >= ' . $start_time_avg . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $avg_period_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        $avg_topics_per_day = ($days_for_average > 0) ? $avg_period_topics / $days_for_average : 0;
        
        // Set output variables for display in the template
        $this->template->assign_vars(array(
            'TOTAL_TOPICS' => $total_topics,
            'RECENT_TOPICS' => $recent_topics,
            'RECENT_DAYS' => $recent_days,
            'OLD_TOPICS' => $old_topics,
            'OLD_DAYS' => $old_days,
            'VERY_OLD_TOPICS' => $very_old_topics,
            'AVG_TOPICS_PER_DAY' => number_format($avg_topics_per_day, 2),
            'AVG_DAYS_PERIOD' => $days_for_average,
            'start_date' => $start_date,
            'end_date' => $end_date,
            'filter_active' => $filter_active,
        ));
        
        // Assign forum distribution to template
        foreach ($forum_distribution as $forum)
        {
            $this->template->assign_block_vars('forum_distribution', array(
                'FORUM_NAME' => $forum['name'],
                'COUNT' => $forum['count'],
                'PERCENTAGE' => round($forum['percentage'], 1),
            ));
        }
        
        // Assign distribution array to template
        foreach ($time_periods as $period) {
            $this->template->assign_block_vars('distribution', array(
                'NAME' => $period['name'],
                'COUNT' => $period['count'],
                'PERCENTAGE' => round($period['percentage'], 1),
            ));
        }
    }

    /**
     * Export statistics in CSV or PDF format
     *
     * @param string $format The export format (csv or pdf)
     * @param string $start_date Start date filter (YYYY-MM-DD)
     * @param string $end_date End date filter (YYYY-MM-DD)
     * @return void
     */
    private function export_statistics($format, $start_date = '', $end_date = '')
    {
        // Load language data
        $this->language->add_lang('info_acp_recenttopics', 'salvocortesiano/recenttopics');
        
        // Get time filter boundaries
        $now = time();
        $start_time = 0;
        $end_time = $now;
        $filter_active = false;
        
        // Parse date filters if provided
        if (!empty($start_date))
        {
            $date_parts = explode('-', $start_date);
            if (count($date_parts) === 3)
            {
                $start_time = mktime(0, 0, 0, (int) $date_parts[1], (int) $date_parts[2], (int) $date_parts[0]);
                $filter_active = true;
            }
        }
        
        if (!empty($end_date))
        {
            $date_parts = explode('-', $end_date);
            if (count($date_parts) === 3)
            {
                $end_time = mktime(23, 59, 59, (int) $date_parts[1], (int) $date_parts[2], (int) $date_parts[0]);
                $filter_active = true;
            }
        }
        
        // Get data for export
        $recent_days = (int) $this->config['recenttopics_days'];
        $old_days = (int) $this->config['recenttopics_old_days'];
        $recent_time = $now - ($recent_days * 24 * 60 * 60);
        $old_time = $now - ($old_days * 24 * 60 * 60);
        
        // Apply date filter to SQL queries if active
        $date_filter_sql = '';
        if ($filter_active)
        {
            $date_filter_sql = ' AND topic_time >= ' . $start_time . ' AND topic_time <= ' . $end_time;
        }
        
        // Get total number of topics
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $total_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get recent topics
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time >= ' . $recent_time . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $recent_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get older topics
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time >= ' . $old_time . '
                AND topic_time < ' . $recent_time . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $old_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get very old topics
        $sql = 'SELECT COUNT(topic_id) as count FROM ' . TOPICS_TABLE . '
                WHERE topic_time < ' . $old_time . '
                AND topic_type <> ' . POST_GLOBAL . $date_filter_sql;
        $result = $this->db->sql_query($sql);
        $very_old_topics = (int) $this->db->sql_fetchfield('count');
        $this->db->sql_freeresult($result);
        
        // Get forum distribution
        $sql = 'SELECT f.forum_name, COUNT(t.topic_id) as count FROM ' . TOPICS_TABLE . ' t
                JOIN ' . FORUMS_TABLE . ' f ON t.forum_id = f.forum_id
                WHERE t.topic_type <> ' . POST_GLOBAL;
                
        if ($filter_active) {
            $sql .= ' AND t.topic_time >= ' . $start_time . ' AND t.topic_time <= ' . $end_time;
        }
        
        $sql .= ' GROUP BY f.forum_id
                ORDER BY count DESC';
        $result = $this->db->sql_query($sql);
        
        $forum_distribution = array();
        while ($row = $this->db->sql_fetchrow($result))
        {
            $forum_distribution[] = array(
                'name' => $row['forum_name'],
                'count' => $row['count'],
                'percentage' => ($total_topics > 0) ? ($row['count'] / $total_topics) * 100 : 0,
            );
        }
        $this->db->sql_freeresult($result);
        
        // Create title and filename
        $filename = 'recenttopics_stats_' . date('Ymd');
        $title = $this->language->lang('RECENTTOPICS_STATISTICS_TITLE');
        
        // Generate content by format
        if ($format === 'csv')
        {
            // Set headers for CSV download
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $filename . '.csv');
            
            // Create output object
            $output = fopen('php://output', 'w');
            
            // Add BOM for UTF-8
            fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
            
            // CSV header row
            fputcsv($output, array(
                $this->language->lang('RECENTTOPICS_STATS_CATEGORY'),
                $this->language->lang('RECENTTOPICS_STATS_COUNT'),
                $this->language->lang('RECENTTOPICS_STATS_PERCENTAGE')
            ));
            
            // Summary section
            fputcsv($output, array(
                $this->language->lang('RECENTTOPICS_STATS_TOTAL_TOPICS'),
                $total_topics,
                '100%'
            ));
            
            fputcsv($output, array(
                sprintf($this->language->lang('RECENTTOPICS_STATS_RECENT_TOPICS'), $recent_days),
                $recent_topics,
                ($total_topics > 0) ? round(($recent_topics / $total_topics) * 100, 1) . '%' : '0%'
            ));
            
            fputcsv($output, array(
                sprintf($this->language->lang('RECENTTOPICS_STATS_OLD_TOPICS'), $recent_days, $old_days),
                $old_topics,
                ($total_topics > 0) ? round(($old_topics / $total_topics) * 100, 1) . '%' : '0%'
            ));
            
            fputcsv($output, array(
                sprintf($this->language->lang('RECENTTOPICS_STATS_VERY_OLD_TOPICS'), $old_days),
                $very_old_topics,
                ($total_topics > 0) ? round(($very_old_topics / $total_topics) * 100, 1) . '%' : '0%'
            ));
            
            // Empty row as separator
            fputcsv($output, array('', '', ''));
            
            // Forum distribution heading
            fputcsv($output, array($this->language->lang('RECENTTOPICS_STATS_FORUM_DISTRIBUTION'), '', ''));
            
            // Forum distribution data
            foreach ($forum_distribution as $forum)
            {
                fputcsv($output, array(
                    $forum['name'],
                    $forum['count'],
                    round($forum['percentage'], 1) . '%'
                ));
            }
            
            // Close the output stream
            fclose($output);
            exit;
        }
        else if ($format === 'pdf')
        {
            // Includere una libreria PDF di base per phpBB
            if (!class_exists('\\TCPDF'))
            {
                // Se non abbiamo TCPDF, reindirizza alla pagina delle statistiche con un messaggio di errore
                trigger_error('PDF export requires TCPDF library. Contact your board administrator.', E_USER_WARNING);
            }
            
            // Create new PDF document
            $pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
            
            // Set document information
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor('phpBB RecentTopics Extension');
            $pdf->SetTitle($title);
            $pdf->SetSubject($title);
            
            // Remove header/footer
            $pdf->setPrintHeader(false);
            $pdf->setPrintFooter(false);
            
            // Set margins
            $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
            
            // Set auto page breaks
            $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
            
            // Set font
            $pdf->SetFont('helvetica', '', 10);
            
            // Add a page
            $pdf->AddPage();
            
            // Add title
            $pdf->SetFont('helvetica', 'B', 16);
            $pdf->Cell(0, 10, $title, 0, 1, 'C');
            $pdf->Ln(5);
            
            // Add date range if filter is active
            if ($filter_active)
            {
                $pdf->SetFont('helvetica', '', 10);
                $date_range = $this->language->lang('RECENTTOPICS_STATS_DATE_RANGE') . ': ';
                if (!empty($start_date))
                {
                    $date_range .= $start_date;
                }
                else
                {
                    $date_range .= $this->language->lang('RECENTTOPICS_STATS_ALL_TIME');
                }
                
                if (!empty($end_date))
                {
                    $date_range .= ' - ' . $end_date;
                }
                
                $pdf->Cell(0, 10, $date_range, 0, 1, 'C');
                $pdf->Ln(5);
            }
            
            // Summary section
            $pdf->SetFont('helvetica', 'B', 12);
            $pdf->Cell(0, 10, $this->language->lang('RECENTTOPICS_STATS_SUMMARY'), 0, 1, 'L');
            $pdf->Ln(2);
            
            $pdf->SetFont('helvetica', '', 10);
            
            // Create summary table
            $summary_table = '<table border="1" cellpadding="5">
                <tr style="background-color: #EEEEEE; font-weight: bold;">
                    <th width="60%">' . $this->language->lang('RECENTTOPICS_STATS_CATEGORY') . '</th>
                    <th width="20%">' . $this->language->lang('RECENTTOPICS_STATS_COUNT') . '</th>
                    <th width="20%">' . $this->language->lang('RECENTTOPICS_STATS_PERCENTAGE') . '</th>
                </tr>
                <tr>
                    <td>' . $this->language->lang('RECENTTOPICS_STATS_TOTAL_TOPICS') . '</td>
                    <td>' . $total_topics . '</td>
                    <td>100%</td>
                </tr>
                <tr>
                    <td>' . sprintf($this->language->lang('RECENTTOPICS_STATS_RECENT_TOPICS'), $recent_days) . '</td>
                    <td>' . $recent_topics . '</td>
                    <td>' . (($total_topics > 0) ? round(($recent_topics / $total_topics) * 100, 1) . '%' : '0%') . '</td>
                </tr>
                <tr>
                    <td>' . sprintf($this->language->lang('RECENTTOPICS_STATS_OLD_TOPICS'), $recent_days, $old_days) . '</td>
                    <td>' . $old_topics . '</td>
                    <td>' . (($total_topics > 0) ? round(($old_topics / $total_topics) * 100, 1) . '%' : '0%') . '</td>
                </tr>
                <tr>
                    <td>' . sprintf($this->language->lang('RECENTTOPICS_STATS_VERY_OLD_TOPICS'), $old_days) . '</td>
                    <td>' . $very_old_topics . '</td>
                    <td>' . (($total_topics > 0) ? round(($very_old_topics / $total_topics) * 100, 1) . '%' : '0%') . '</td>
                </tr>
            </table>';
            
            // Write summary table
            $pdf->writeHTML($summary_table, true, false, true, false, '');
            $pdf->Ln(10);
            
            // Forum distribution section
            $pdf->SetFont('helvetica', 'B', 12);
            $pdf->Cell(0, 10, $this->language->lang('RECENTTOPICS_STATS_FORUM_DISTRIBUTION'), 0, 1, 'L');
            $pdf->Ln(2);
            
            $pdf->SetFont('helvetica', '', 10);
            
            // Create forum distribution table
            $forum_table = '<table border="1" cellpadding="5">
                <tr style="background-color: #EEEEEE; font-weight: bold;">
                    <th width="60%">' . $this->language->lang('RECENTTOPICS_STATS_FORUM') . '</th>
                    <th width="20%">' . $this->language->lang('RECENTTOPICS_STATS_COUNT') . '</th>
                    <th width="20%">' . $this->language->lang('RECENTTOPICS_STATS_PERCENTAGE') . '</th>
                </tr>';
            
            foreach ($forum_distribution as $forum)
            {
                $forum_table .= '<tr>
                    <td>' . $forum['name'] . '</td>
                    <td>' . $forum['count'] . '</td>
                    <td>' . round($forum['percentage'], 1) . '%</td>
                </tr>';
            }
            
            $forum_table .= '</table>';
            
            // Write forum distribution table
            $pdf->writeHTML($forum_table, true, false, true, false, '');
            
            // Output the PDF
            $pdf->Output($filename . '.pdf', 'D');
            exit;
        }
        
        // Redirect back to statistics page if format is invalid
        redirect($this->u_action);
    }

    /**
     * Set page url
     *
     * @param string $u_action Custom form action
     * @return void
     */
    public function set_page_url($u_action)
    {
        $this->u_action = $u_action;
    }

    /**
     * Gets the list of forums to display in the dropdown
     *
     * @return string HTML forum options
     */
    private function get_forum_options()
    {
        // Select forums from the database
        $sql = 'SELECT forum_id, forum_name, parent_id, forum_type, left_id, right_id
                FROM ' . FORUMS_TABLE . '
                ORDER BY left_id ASC';
        $result = $this->db->sql_query($sql);

        $forum_options = '';
        $selected_forums = [];
        $all_forums_selected = false;
        
        // Get currently selected forums from config
        if (!empty($this->config['recenttopics_forums']))
        {
            $selected_forums = explode(',', $this->config['recenttopics_forums']);
            // Controlla se è selezionato "Tutti i forum"
            $all_forums_selected = in_array('0', $selected_forums);
        }
        
        // Build a nested, hierarchical forum structure
        $forum_list = [];
        while ($row = $this->db->sql_fetchrow($result))
        {
            // Skip categories
            if ($row['forum_type'] == FORUM_CAT)
            {
                continue;
            }
            
            // Store the forum data
            $forum_list[$row['forum_id']] = [
                'forum_id' => $row['forum_id'],
                'forum_name' => $row['forum_name'],
                'parent_id' => $row['parent_id'],
                'selected' => in_array($row['forum_id'], $selected_forums)
            ];
        }
        $this->db->sql_freeresult($result);
        
        // Build the HTML options for the form
        foreach ($forum_list as $forum_id => $forum_data)
        {
            $selected = $forum_data['selected'] ? ' selected="selected"' : '';
            $forum_options .= '<option value="' . $forum_id . '"' . $selected . '>' . $forum_data['forum_name'] . '</option>';
        }
        
        // Aggiungi l'attributo selected all'opzione "Tutti i forum" se necessario
        if ($all_forums_selected)
        {
            $this->template->assign_var('ALL_FORUMS_SELECTED', true);
        }
        
        return $forum_options;
    }
}
