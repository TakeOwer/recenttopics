<?php
/**
 * Recent Topics Extension for phpBB.
 *
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 * Main extension class that handles installation and activation requirements.
 */

namespace salvocortesiano\recenttopics;

/**
 * This ext class is optional and can be omitted if left empty.
 * However, it provides useful features like pre-installation requirements check.
 */
class ext extends \phpbb\extension\base
{
    /**
     * Check whether the extension can be enabled.
     * Checks for PHP version, phpBB version, and other requirements.
     *
     * @return bool|array True if the extension can be enabled, or Array with error message if not
     */
    public function is_enableable()
    {
        // Check phpBB requirements
        $config = $this->container->get('config');
        if (version_compare($config['version'], '3.2.0', '<'))
        {
            // phpBB version too old
            return array(
                'message' => 'This extension requires phpBB 3.2.0 or newer. Your version is: ' . $config['version'],
            );
        }

        // Check PHP requirements
        if (version_compare(PHP_VERSION, '5.4.0', '<'))
        {
            return array(
                'message' => 'This extension requires PHP 5.4.0 or newer. Your version is: ' . PHP_VERSION,
            );
        }

        return true;
    }
    
    /**
     * Perform any actions needed when the extension is disabled.
     *
     * @param mixed $old_state State information from before disable 
     * @return void
     */
    public function disable_step($old_state)
    {
        // Clear any cached assets if needed
        if ($this->container->has('cache.driver'))
        {
            $this->container->get('cache.driver')->purge();
        }
        
        return parent::disable_step($old_state);
    }
}
