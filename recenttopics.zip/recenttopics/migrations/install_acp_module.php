<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

namespace salvocortesiano\recenttopics\migrations;

class install_acp_module extends \phpbb\db\migration\migration
{
    public function effectively_installed()
    {
        return isset($this->config['recenttopics_version']) && version_compare($this->config['recenttopics_version'], '1.0.1', '>=');
    }

    static public function depends_on()
    {
        return array('\phpbb\db\migration\data\v31x\v314');
    }

    public function update_data()
    {
        return array(
            // Add config variables
            array('config.add', array('recenttopics_version', '1.0.1')),
            array('config.add', array('recenttopics_enabled', 1)),
            array('config.add', array('recenttopics_days', 7)),
            array('config.add', array('recenttopics_old_days', 90)),  // Nuovo: giorni dopo i quali un topic è considerato vecchio
            array('config.add', array('recenttopics_animation', 1)),
            array('config.add', array('recenttopics_days_tier1', 1)),
            array('config.add', array('recenttopics_days_tier2', 3)),
            array('config.add', array('recenttopics_days_tier3', 7)),
            array('config.add', array('recenttopics_icon_tier1', 'star')),
            array('config.add', array('recenttopics_icon_tier2', 'zap')),
            array('config.add', array('recenttopics_icon_tier3', 'clock')),
            array('config.add', array('recenttopics_show_all_topics', 0)),
            
            // Add ACP module
            array('module.add', array(
                'acp',
                'ACP_CAT_DOT_MODS',
                'ACP_RECENTTOPICS_TITLE'
            )),
            array('module.add', array(
                'acp',
                'ACP_RECENTTOPICS_TITLE',
                array(
                    'module_basename' => '\salvocortesiano\recenttopics\acp\main_module',
                    'modes' => array('settings', 'statistics'),
                ),
            )),
        );
    }
}
