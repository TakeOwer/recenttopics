<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

namespace salvocortesiano\recenttopics\acp;

/**
 * Recent Topics ACP module
 */
class main_module
{
    /** @var string The page title */
    public $u_action;
    
    /** @var string The page title */
    public $tpl_name;
    
    /** @var string The page title */
    public $page_title;
    
    /**
     * Main ACP module
     *
     * @param int    $id   The module ID
     * @param string $mode The module mode
     * @return void
     */
    public function main($id, $mode)
    {
        global $phpbb_container;
        
        // Load a language file
        $language = $phpbb_container->get('language');
        $language->add_lang('info_acp_recenttopics', 'salvocortesiano/recenttopics');
        
        // Get an instance of the admin controller
        $admin_controller = $phpbb_container->get('salvocortesiano.recenttopics.controller.acp');
        
        // Make the u_action url available in the admin controller
        $admin_controller->set_page_url($this->u_action);
        
        // Load the appropriate handle
        switch ($mode)
        {
            case 'settings':
                // Set page template and title
                $this->tpl_name = 'acp_recenttopics_settings';
                $this->page_title = $language->lang('ACP_RECENTTOPICS_SETTINGS');
                $admin_controller->display_settings();
            break;
            
            case 'statistics':
                // Set page template and title
                $this->tpl_name = 'acp_recenttopics_stats';
                $this->page_title = $language->lang('ACP_RECENTTOPICS_STATISTICS');
                $admin_controller->display_statistics();
            break;
            
            default:
                // Default to settings
                $this->tpl_name = 'acp_recenttopics_settings';
                $this->page_title = $language->lang('ACP_RECENTTOPICS_SETTINGS');
                $admin_controller->display_settings();
            break;
        }
    }
}
