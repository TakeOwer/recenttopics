<?php
/**
 * Recent Topics Marker Extension for phpBB.
 * @copyright (c) 2023 Extension Author
 * @license GNU General Public License, version 2 (GPL-2.0)
 */

namespace salvocortesiano\recenttopics\acp;

/**
 * Recent Topics ACP module info
 */
class main_info
{
    /**
     * Set up the ACP module
     *
     * @return array ACP module data
     */
    public function module()
    {
        return array(
            'filename'  => '\salvocortesiano\recenttopics\acp\main_module',
            'title'     => 'ACP_RECENTTOPICS_TITLE',
            'modes'     => array(
                'settings'  => array(
                    'title' => 'ACP_RECENTTOPICS_SETTINGS',
                    'auth'  => 'ext_salvocortesiano/recenttopics && acl_a_board',
                    'cat'   => array('ACP_RECENTTOPICS_TITLE'),
                ),
                'statistics'  => array(
                    'title' => 'ACP_RECENTTOPICS_STATISTICS',
                    'auth'  => 'ext_salvocortesiano/recenttopics && acl_a_board',
                    'cat'   => array('ACP_RECENTTOPICS_TITLE'),
                ),
            ),
        );
    }
}
